import { Briefcase, Target, BookOpen, Heart, Lightbulb, Users } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";

const personalities = [
  {
    icon: Briefcase,
    type: "The Business Pro",
    description: "Your inbox is all about deals, meetings, and professional growth. You're focused on career advancement.",
    traits: ["Client-focused", "Meeting-heavy", "Strategic"],
    color: "bg-rose-700",
    gradient: "from-rose-700 to-rose-800"
  },
  {
    icon: Target,
    type: "The Productivity Guru",
    description: "Tools, workflows, and optimization. You're always looking for ways to work smarter and achieve more.",
    traits: ["Efficiency-driven", "Tool collector", "Goal-oriented"],
    color: "bg-orange-600",
    gradient: "from-orange-600 to-orange-700"
  },
  {
    icon: BookOpen,
    type: "The Self Improver",
    description: "Learning never stops for you. Your inbox is filled with courses, books, and personal development content.",
    traits: ["Growth mindset", "Curious learner", "Reflective"],
    color: "bg-rose-800",
    gradient: "from-rose-800 to-rose-900"
  },
  {
    icon: Heart,
    type: "The Socializer",
    description: "Personal connections matter most. Your inbox shows strong relationships and community engagement.",
    traits: ["People-oriented", "Community-driven", "Empathetic"],
    color: "bg-amber-600",
    gradient: "from-amber-600 to-orange-600"
  },
  {
    icon: Lightbulb,
    type: "The Creator",
    description: "Ideas and inspiration flow through your inbox. You're building, making, and bringing visions to life.",
    traits: ["Innovative", "Inspired", "Entrepreneurial"],
    color: "bg-orange-700",
    gradient: "from-orange-700 to-rose-700"
  },
  {
    icon: Users,
    type: "The Balanced One",
    description: "You maintain harmony between work, personal growth, and relationships. A well-rounded inbox personality.",
    traits: ["Well-balanced", "Adaptable", "Mindful"],
    color: "bg-rose-900",
    gradient: "from-rose-900 to-rose-950"
  }
];

export function PersonalityTypes() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section className="px-6 py-20 lg:px-8 lg:py-32 bg-gradient-to-br from-orange-50 via-rose-50 to-amber-50 relative overflow-hidden">
      {/* Decorative background blobs */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-rose-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
        <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-orange-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
      </div>

      <div className="mx-auto max-w-7xl">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl lg:text-5xl tracking-tight text-gray-900 mb-4">
            What's your inbox personality?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our AI analyzes your email patterns to reveal insights about your priorities, habits, and communication style.
          </p>
        </motion.div>

        <motion.div 
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {personalities.map((personality, index) => {
            const Icon = personality.icon;
            return (
              <motion.div 
                key={index} 
                variants={itemVariants}
                whileHover={{ scale: 1.03, transition: { duration: 0.3 } }}
              >
                <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-white/50 group h-full bg-white/80 backdrop-blur-sm">
                  <motion.div 
                    className={`h-2 bg-gradient-to-r ${personality.gradient}`}
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.6 }}
                  ></motion.div>
                  <div className="p-6">
                    <motion.div 
                      className={`w-14 h-14 rounded-full ${personality.color} bg-opacity-10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                      whileHover={{ rotate: 360, transition: { duration: 0.6 } }}
                    >
                      <Icon className={`w-7 h-7 ${personality.color} text-white`} />
                    </motion.div>
                    <h3 className="text-xl mb-3 text-gray-900">{personality.type}</h3>
                    <p className="text-gray-600 mb-4">{personality.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {personality.traits.map((trait, i) => (
                        <Badge key={i} variant="secondary" className="text-xs bg-rose-100 text-rose-800 hover:bg-rose-200">
                          {trait}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}