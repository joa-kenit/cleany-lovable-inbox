import { Mail, Twitter, Github, Linkedin } from "lucide-react";
import { motion } from "framer-motion";

export function Footer() {
  return (
    <footer className="px-6 py-12 lg:px-8 border-t border-rose-200">
      <motion.div 
        className="mx-auto max-w-7xl"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true, margin: "-50px" }}
        transition={{ duration: 0.6 }}
      >
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <Mail className="w-6 h-6 text-rose-800" />
              <span className="text-xl text-rose-900">Cleany</span>
            </div>
            <p className="text-sm text-rose-800/70 mb-4">
              Clean your inbox. Know yourself better.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-rose-400 hover:text-rose-600">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-rose-400 hover:text-rose-600">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-rose-400 hover:text-rose-600">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm text-rose-900 mb-4">Product</h4>
            <ul className="space-y-3 text-sm text-rose-800/70">
              <li><a href="#" className="hover:text-rose-900">Features</a></li>
              <li><a href="#" className="hover:text-rose-900">Pricing</a></li>
              <li><a href="#" className="hover:text-rose-900">Security</a></li>
              <li><a href="#" className="hover:text-rose-900">Roadmap</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm text-rose-900 mb-4">Company</h4>
            <ul className="space-y-3 text-sm text-rose-800/70">
              <li><a href="#" className="hover:text-rose-900">About</a></li>
              <li><a href="#" className="hover:text-rose-900">Blog</a></li>
              <li><a href="#" className="hover:text-rose-900">Careers</a></li>
              <li><a href="#" className="hover:text-rose-900">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm text-rose-900 mb-4">Legal</h4>
            <ul className="space-y-3 text-sm text-rose-800/70">
              <li><a href="#" className="hover:text-rose-900">Privacy</a></li>
              <li><a href="#" className="hover:text-rose-900">Terms</a></li>
              <li><a href="#" className="hover:text-rose-900">Cookie Policy</a></li>
              <li><a href="#" className="hover:text-rose-900">Licenses</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-rose-200 text-center text-sm text-rose-800/70">
          <p>&copy; 2025 Cleany. All rights reserved.</p>
        </div>
      </motion.div>
    </footer>
  );
}