import { ArrowRight } from "lucide-react";
import { motion } from "motion/react";

const steps = [
  {
    number: "01",
    title: "Connect Your Gmail",
    description: "Securely connect your Google account in seconds with OAuth authentication."
  },
  {
    number: "02",
    title: "Emails Grouped by Sender",
    description: "We organize your emails by sender so you can easily see who's taking up the most space."
  },
  {
    number: "03",
    title: "Review & Delete",
    description: "Browse through senders and use bulk actions to delete unwanted emails and free up space."
  },
  {
    number: "04",
    title: "Discover Your Personality",
    description: "Get your unique inbox personality profile with insights into your email habits and communication style."
  }
];

export function HowItWorks() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section className="px-6 py-20 lg:px-8 lg:py-32 bg-white">
      <div className="mx-auto max-w-7xl">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl lg:text-5xl tracking-tight text-gray-900 mb-4">
            How it works
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get started in minutes and transform your inbox experience forever.
          </p>
        </motion.div>

        <motion.div 
          className="grid gap-8 md:grid-cols-2 lg:grid-cols-4"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {steps.map((step, index) => (
            <motion.div 
              key={index} 
              className="relative"
              variants={itemVariants}
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
            >
              <div className="flex flex-col items-center text-center">
                <motion.div 
                  className="text-6xl mb-4 bg-gradient-to-br from-rose-700 to-orange-600 bg-clip-text text-transparent opacity-30"
                  initial={{ scale: 0.5, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 0.3 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 + 0.3, duration: 0.5 }}
                >
                  {step.number}
                </motion.div>
                <h3 className="text-xl mb-3 text-rose-900">{step.title}</h3>
                <p className="text-rose-800/70">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <motion.div 
                  className="hidden lg:block absolute top-12 left-full w-full"
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 + 0.5, duration: 0.5 }}
                >
                  <ArrowRight className="w-6 h-6 text-rose-300 -ml-3" />
                </motion.div>
              )}
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}