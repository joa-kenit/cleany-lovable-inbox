
  # Landing Page for Cleany

  This is a code bundle for Landing Page for Cleany. The original project is available at https://www.figma.com/design/yOtbUtDe0EXRZ9Cu0MEMIo/Landing-Page-for-Cleany.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  